#ifndef COMPLAINT_SYSTEM_H
#define COMPLAINT_SYSTEM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#ifdef _WIN32
#include <direct.h>
#define CREATE_DIR(dir) _mkdir(dir)
#else
#include <sys/stat.h>
#define CREATE_DIR(dir) mkdir(dir, 0755)
#endif

#define MAX_AGENTS 10
#define BUFFER_SIZE 512

/* Nested Structure for Timestamps */
typedef struct {
    char registered[26];
    char assigned[26];
    char updated[26];
    char resolved[26];
    char closed[26];
    char escalated[26];
} ComplaintTimestamps;

/* Singly Linked List Node for Chronological Audit Trail */
typedef struct AuditNode {
    char complaintId[16];
    char timestamp[26];
    char action[32];
    char performedBy[32];
    char details[128];
    struct AuditNode *next;
} AuditNode;

/* Structure for Complaint Data with Nested Timestamps */
typedef struct {
    char complaintId[16];
    char customerId[16];
    char category[32];
    char priority[16];
    char status[20];
    char assignedAgentId[16];
    char lastNote[128];
    char description[256];
    ComplaintTimestamps timestamps;
} Complaint;

/* Singly Linked List Node for Complaints */
typedef struct ComplaintNode {
    Complaint data;
    AuditNode *auditHead;
    struct ComplaintNode *next;
} ComplaintNode;

/* Structure for Customer Profile */
typedef struct {
    char customerId[16];
    char fullName[64];
    char username[32];
    char password[32];
    char contact[64];
} Customer;

/* Singly Linked List Node for Customers */
typedef struct CustomerNode {
    Customer data;
    struct CustomerNode *next;
} CustomerNode;

/* Structure for Agent */
typedef struct {
    char agentId[16];
    char fullName[64];
    char username[32];
    char password[32];
    int isActive;
    int resolvedCount;
} Agent;

/* Structure for Manager */
typedef struct {
    char username[32];
    char password[32];
    char fullName[64];
} Manager;

/* Application-defined function declarations (Total: 29 functions including main) */
void getTimestamp(char *buffer, size_t size);
void readString(const char *prompt, char *buffer, size_t size);
int readInt(const char *prompt, int minVal, int maxVal);
CustomerNode* findCustomerByUsername(const char *username);
ComplaintNode* findComplaintById(const char *complaintId);
void addAuditEntry(ComplaintNode *node, const char *action, const char *by, const char *details);
int autoAssignAgent(void);
void initSystem(void);
void saveAllData(void);
void freeAllMemory(void);
void customerMenu(void);
void customerRegister(void);
void customerLogin(void);
void customerDashboard(const char *customerId, const char *customerName);
void customerRegisterComplaint(const char *customerId);
void customerViewComplaints(const char *customerId);
void customerTrackComplaint(const char *customerId);
void customerViewHistory(const char *customerId);
void agentMenu(void);
void agentDashboard(int agentIdx);
void agentViewAssigned(const char *agentId);
void agentUpdateComplaint(const char *agentId);
void managerMenu(void);
void managerDashboard(void);
void managerViewAllComplaints(void);
void managerAssignComplaint(void);
void managerUpdateComplaint(void);
void managerAgentManagement(void);
int main(void);

#endif /* COMPLAINT_SYSTEM_H */
