# Function Inventory — Complaint Handling System

This document provides a complete, exhaustive inventory of all **29 application function definitions** implemented in the Complaint Handling System (`src/main.c`).

Every function is analysed for purpose, signatures, control flow, loops, branches, side effects, error handling, and test requirements.

---

## Summary Matrix of All 29 Functions

| # | Function Name | Source Location | Parameters | Return Type | Category |
|---|---|---|---|---|---|
| 1 | `getTimestamp` | `src/main.c:34` | `(char *buffer, size_t size)` | `void` | Utility / DateTime |
| 2 | `readString` | `src/main.c:49` | `(const char *prompt, char *buffer, size_t size)` | `void` | Input & Validation |
| 3 | `readInt` | `src/main.c:79` | `(const char *prompt, int minVal, int maxVal)` | `int` | Input & Validation |
| 4 | `findCustomerByUsername` | `src/main.c:106` | `(const char *username)` | `CustomerNode*` | Customer Query |
| 5 | `findComplaintById` | `src/main.c:122` | `(const char *complaintId)` | `ComplaintNode*` | Complaint Query |
| 6 | `addAuditEntry` | `src/main.c:138` | `(ComplaintNode *node, const char *action, const char *by, const char *details)` | `void` | Audit Management |
| 7 | `autoAssignAgent` | `src/main.c:168` | `(void)` | `int` | Agent Allocation |
| 8 | `initSystem` | `src/main.c:200` | `(void)` | `void` | System Lifecycle & I/O |
| 9 | `saveAllData` | `src/main.c:379` | `(void)` | `void` | Persistence & I/O |
| 10 | `freeAllMemory` | `src/main.c:456` | `(void)` | `void` | Memory Management |
| 11 | `customerMenu` | `src/main.c:484` | `(void)` | `void` | Customer Portal UI |
| 12 | `customerRegister` | `src/main.c:508` | `(void)` | `void` | Customer Registration |
| 13 | `customerLogin` | `src/main.c:573` | `(void)` | `void` | Customer Authentication |
| 14 | `customerDashboard` | `src/main.c:593` | `(const char *customerId, const char *customerName)` | `void` | Customer Dashboard UI |
| 15 | `customerRegisterComplaint` | `src/main.c:624` | `(const char *customerId)` | `void` | Complaint Registration |
| 16 | `customerViewComplaints` | `src/main.c:731` | `(const char *customerId)` | `void` | Customer Query UI |
| 17 | `customerTrackComplaint` | `src/main.c:765` | `(const char *customerId)` | `void` | Complaint Tracking UI |
| 18 | `customerViewHistory` | `src/main.c:823` | `(const char *customerId)` | `void` | Customer Audit UI |
| 19 | `agentMenu` | `src/main.c:861` | `(void)` | `void` | Agent Portal UI |
| 20 | `agentDashboard` | `src/main.c:905` | `(int agentIdx)` | `void` | Agent Dashboard UI |
| 21 | `agentViewAssigned` | `src/main.c:961` | `(const char *agentId)` | `void` | Agent Query UI |
| 22 | `agentUpdateComplaint` | `src/main.c:995` | `(const char *agentId)` | `void` | Agent Workflow UI |
| 23 | `managerMenu` | `src/main.c:1064` | `(void)` | `void` | Manager Portal UI |
| 24 | `managerDashboard` | `src/main.c:1096` | `(void)` | `void` | Manager Dashboard UI |
| 25 | `managerViewAllComplaints` | `src/main.c:1150` | `(void)` | `void` | Manager Analytics UI |
| 26 | `managerAssignComplaint` | `src/main.c:1200` | `(void)` | `void` | Manager Allocation UI |
| 27 | `managerUpdateComplaint` | `src/main.c:1277` | `(void)` | `void` | Manager Workflow UI |
| 28 | `managerAgentManagement` | `src/main.c:1340` | `(void)` | `void` | Manager Roster UI |
| 29 | `main` | `src/main.c:1397` | `(void)` | `int` | Application Entry Point |

---

## Detailed Specifications for All 29 Functions

### Function 1: `getTimestamp`
- **Source File & Line:** `src/main.c:34-43`
- **Purpose:** Formats the current system calendar time into a standardized ISO-like datetime string (`YYYY-MM-DD HH:MM:SS`) using `<time.h>`.
- **Parameters:**
  - `char *buffer`: Destination character array.
  - `size_t size`: Capacity of `buffer` in bytes.
- **Valid Input Ranges:** Non-null `buffer`, `size >= 20` bytes for complete datetime string.
- **Return Type & Expected Result:** `void`. Destination buffer is populated with formatted timestamp or `"N/A"`.
- **Normal Execution Paths:** Obtains epoch time via `time(NULL)`, decomposes with `localtime()`, formats using `strftime(buffer, size, "%Y-%m-%d %H:%M:%S", tm_info)`.
- **Conditional Branches:**
  - `if (buffer == NULL || size == 0)`: Defensive early return.
  - `if (tm_info != NULL)`: Successful conversion branch.
  - `else`: System call failure branch writing `"N/A"`.
- **Loop Conditions & Termination:** None.
- **Error Handling & Defensive Checks:** Guards against NULL pointer and zero size; handles `localtime()` failure safely without buffer overflow.
- **Side Effects:** Writes to caller-supplied buffer.
- **Relevant Test Scenarios:**
  - Normal valid timestamp generation matching regex `^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$`.
  - Defensive check: `buffer == NULL`.
  - Defensive check: `size == 0`.
  - Boundary: small buffer size (`size == 5`).
  - System call failure: mock `localtime` returning NULL -> produces `"N/A"`.

---

### Function 2: `readString`
- **Source File & Line:** `src/main.c:49-73`
- **Purpose:** Safely reads an interactive string from standard input (`stdin`), strips trailing newline and carriage-return characters, and sanitizes pipe (`|`) delimiter characters to prevent persistent file format corruption.
- **Parameters:**
  - `const char *prompt`: Prompt message printed to `stdout` before reading, or NULL / empty string.
  - `char *buffer`: Target buffer.
  - `size_t size`: Maximum characters to read including null terminator.
- **Valid Input Ranges:** Non-null `buffer`, `size > 0`.
- **Return Type & Expected Result:** `void`. Buffer populated with sanitized string.
- **Normal Execution Paths:** Prints prompt if present, invokes `fgets(buffer, (int)size, stdin)`, strips trailing `\n` and `\r`, scans and replaces any `|` with `-`.
- **Conditional Branches:**
  - `if (prompt != NULL && prompt[0] != '\0')`: Prints prompt and flushes `stdout`.
  - `if (buffer == NULL || size == 0)`: Defensive early exit.
  - `if (fgets(...) == NULL)`: Handles EOF or read error by setting `buffer[0] = '\0'`.
  - `if (buffer[i] == '|')`: Delimiter character sanitization.
- **Loop Conditions & Termination:**
  - `while (len > 0 && (buffer[len - 1] == '\n' || buffer[len - 1] == '\r'))`: Strips newlines until exhausted or string empty.
  - `for (size_t i = 0; i < len; i++)`: Iterates entire length to replace delimiter characters.
- **Error Handling & Defensive Checks:** Handles NULL prompt, NULL buffer, zero size, and immediate EOF.
- **Side Effects:** Reads `stdin`, writes prompt to `stdout`, modifies `buffer`.
- **Relevant Test Scenarios:**
  - Standard alphanumeric input with trailing `\n`.
  - Windows CRLF (`\r\n`) trailing line terminators.
  - Pipe sanitization: input containing `foo|bar|baz` converted to `foo-bar-baz`.
  - NULL prompt (no prompt displayed).
  - Empty prompt `""`.
  - Immediate EOF on stdin (`fgets` returns NULL -> `buffer[0] = '\0'`).
  - Empty line input (just `\n`).
  - NULL buffer and size 0 guards.

---

### Function 3: `readInt`
- **Source File & Line:** `src/main.c:79-100`
- **Purpose:** Robust integer input parser validating user input within an inclusive range `[minVal, maxVal]`, flushing invalid tokens and preventing infinite loops.
- **Parameters:**
  - `const char *prompt`: Display prompt.
  - `int minVal`: Minimum valid inclusive integer.
  - `int maxVal`: Maximum valid inclusive integer.
- **Valid Input Ranges:** `minVal <= maxVal`.
- **Return Type & Expected Result:** `int`. A parsed integer guaranteed to satisfy `minVal <= result <= maxVal`.
- **Normal Execution Paths:** Loops reading string input, converts using `strtol`, verifies full string conversion (`*endptr == '\0'`), verifies bounds, and returns value.
- **Conditional Branches:**
  - `if (buffer[0] == '\0')`: If `feof(stdin)` returns `minVal` (EOF safeguard); else prompts non-empty.
  - `if (endptr != buffer && *endptr == '\0')`: Verifies valid numeric parse.
  - `if (parsed >= minVal && parsed <= maxVal)`: Successful range match.
- **Loop Conditions & Termination:**
  - `while (1)`: Loops until a valid integer in range is provided, or stdin reaches EOF.
- **Error Handling & Defensive Checks:** Rejects alphabetic input, mixed alphanumeric strings (e.g. `12abc`), empty lines, out-of-range low and high values. Provides EOF safety termination.
- **Side Effects:** Writes prompts and error messages to `stdout`, consumes `stdin`.
- **Relevant Test Scenarios:**
  - Valid integer within range.
  - Boundary: exact `minVal`.
  - Boundary: exact `maxVal`.
  - Input below `minVal` rejected then valid entered.
  - Input above `maxVal` rejected then valid entered.
  - Non-numeric input (`abc`) rejected then valid entered.
  - Alphanumeric string (`12xyz`) rejected then valid entered.
  - Empty string (`\n`) rejected then valid entered.
  - EOF condition returning `minVal`.

---

### Function 4: `findCustomerByUsername`
- **Source File & Line:** `src/main.c:106-116`
- **Purpose:** Traverses the singly linked list of registered customers to find an account matching the given unique username.
- **Parameters:**
  - `const char *username`: Unique username string to look up.
- **Valid Input Ranges:** Non-null, non-empty C-string.
- **Return Type & Expected Result:** `CustomerNode*`. Pointer to matching customer node if found; `NULL` otherwise.
- **Normal Execution Paths:** Sets `curr = customerHead`, iterates while `curr != NULL`, performs `strcmp(curr->data.username, username) == 0`.
- **Conditional Branches:**
  - `if (username == NULL || username[0] == '\0') return NULL;`: Defensive input check.
  - `if (strcmp(...) == 0) return curr;`: Match found.
- **Loop Conditions & Termination:**
  - `while (curr != NULL)`: Terminates on match (early return) or when list end reached (`curr == NULL`).
- **Error Handling & Defensive Checks:** Handles NULL pointer, empty string, and empty linked list safely.
- **Side Effects:** Read-only traversal; no side effects.
- **Relevant Test Scenarios:**
  - Search in empty customer list -> returns NULL.
  - Search with NULL username -> returns NULL.
  - Search with empty string `""` -> returns NULL.
  - Single-node list: matching item at head.
  - Single-node list: non-matching item.
  - Multi-node list: match first element.
  - Multi-node list: match middle element.
  - Multi-node list: match last element.
  - Multi-node list: target not in list after full traversal.

---

### Function 5: `findComplaintById`
- **Source File & Line:** `src/main.c:122-132`
- **Purpose:** Traverses the singly linked list of complaints to find a record matching the unique complaint identifier (e.g. `"CMP101"`).
- **Parameters:**
  - `const char *complaintId`: Identifier string.
- **Valid Input Ranges:** Non-null, non-empty C-string.
- **Return Type & Expected Result:** `ComplaintNode*`. Pointer to matching complaint node, or `NULL` if not found.
- **Normal Execution Paths:** Sets `curr = complaintHead`, traverses nodes comparing `curr->data.complaintId` with `complaintId`.
- **Conditional Branches:**
  - `if (complaintId == NULL || complaintId[0] == '\0') return NULL;`: Input validation.
  - `if (strcmp(...) == 0) return curr;`: Match found.
- **Loop Conditions & Termination:**
  - `while (curr != NULL)`: Exits on match or at end of linked list.
- **Error Handling & Defensive Checks:** Handles NULL pointer, empty string, and empty list safely.
- **Side Effects:** Read-only traversal; no side effects.
- **Relevant Test Scenarios:**
  - Search in empty complaint list.
  - NULL complaintId.
  - Empty string `""`.
  - Multi-node list: match head element.
  - Multi-node list: match middle element.
  - Multi-node list: match tail element.
  - Multi-node list: non-existent ID.

---

### Function 6: `addAuditEntry`
- **Source File & Line:** `src/main.c:138-162`
- **Purpose:** Dynamically allocates a new chronological audit event node (`AuditNode`) and appends it to the end of a complaint's singly linked audit trail.
- **Parameters:**
  - `ComplaintNode *node`: Target complaint node.
  - `const char *action`: Short action identifier (e.g. `"REGISTERED"`).
  - `const char *by`: Actor identity (e.g. `"SYSTEM"`, `"AGT101"`, `"manager"`).
  - `const char *details`: Descriptive detail of the action.
- **Valid Input Ranges:** Valid pointer to `ComplaintNode`. Strings may be NULL (handled defensively).
- **Return Type & Expected Result:** `void`. Node's `auditHead` contains newly appended audit event.
- **Normal Execution Paths:** Allocates `sizeof(AuditNode)`, populates complaint ID, current timestamp, action, actor, details, sets `next = NULL`. Appends to head if `auditHead == NULL`, or traverses to tail and links.
- **Conditional Branches:**
  - `if (node == NULL) return;`: Defensive check.
  - `if (newAudit == NULL)`: Memory allocation failure check.
  - `action ? action : "ACTION"`, `by ? by : "SYSTEM"`, `details ? details : ""`: Fallbacks for NULL strings.
  - `if (node->auditHead == NULL)`: First audit entry in complaint.
  - `else`: Traversal to tail branch.
- **Loop Conditions & Termination:**
  - `while (curr->next != NULL)`: Traverses to the last node in the audit chain.
- **Error Handling & Defensive Checks:** Handles NULL node pointer, heap exhaustion (`malloc` returning NULL), and NULL string parameters.
- **Side Effects:** Allocates heap memory, modifies complaint's `auditHead` chain.
- **Relevant Test Scenarios:**
  - Defensive check: `node == NULL`.
  - First audit entry appended to a node with `auditHead == NULL`.
  - Second and third audit entries appended to existing audit chain.
  - NULL action, NULL by, NULL details fallback verification.
  - Malloc failure injection (verifies error message and no crash).

---

### Function 7: `autoAssignAgent`
- **Source File & Line:** `src/main.c:168-193`
- **Purpose:** Determines the active support agent with the lowest open workload (active tickets neither `"RESOLVED"` nor `"CLOSED"`) for load-balanced ticket allocation.
- **Parameters:** `void`.
- **Valid Input Ranges:** N/A (reads global `agents` array and `complaintHead`).
- **Return Type & Expected Result:** `int`. Agent index `[0, MAX_AGENTS - 1]` representing optimal agent, or `-1` if no active agents exist.
- **Normal Execution Paths:** Iterates through all 10 agents in `agents[]`. If agent is active, traverses `complaintHead` counting tickets matching `assignedAgentId` where status is not `"RESOLVED"` and not `"CLOSED"`. Identifies minimum workload.
- **Conditional Branches:**
  - `if (!agents[i].isActive) continue;`: Skips inactive agents.
  - `if (strcmp(curr->data.assignedAgentId, agents[i].agentId) == 0)`: Checks ticket assignment.
  - `if (strcmp(...) != 0 && strcmp(...) != 0)`: Filters out resolved/closed tickets.
  - `if (activeWorkload < minWorkload)`: Tracks candidate with lower workload.
- **Loop Conditions & Termination:**
  - `for (int i = 0; i < MAX_AGENTS; i++)`: Iterates through all 10 agents.
  - `while (curr != NULL)`: Traverses complaint linked list for each active agent.
- **Error Handling & Defensive Checks:** Handles scenario where all agents are inactive by returning `-1`.
- **Side Effects:** Read-only calculation over global application state.
- **Relevant Test Scenarios:**
  - Fresh state: 0 complaints -> selects Agent 0 (workload 0).
  - All 10 agents marked inactive -> returns `-1`.
  - Agent 0 has 2 open complaints, Agent 1 has 1 open complaint -> selects Agent 1.
  - Resolved and Closed complaints do not contribute to active workload.
  - Inactive agent with 0 complaints is skipped in favor of active agent with higher workload.

---

### Function 8: `initSystem`
- **Source File & Line:** `src/main.c:200-373`
- **Purpose:** Initializes application state: ensures storage directory `data/` exists, provisions or reads predefined support agents (`data/agents.txt`), restores sequential ID counters (`data/counters.txt`), loads customers (`data/customers.txt`), loads complaints with nested timestamps (`data/complaints.txt`), and loads chronological audit history (`data/audit_log.txt`).
- **Parameters:** `void`.
- **Valid Input Ranges:** N/A.
- **Return Type & Expected Result:** `void`. Global data structures populated.
- **Normal Execution Paths:** Calls `CREATE_DIR("data")`, parses files if present or writes defaults, links loaded customers, complaints, and audit nodes. Clamps counters to `>= 101` and `>= 1001`.
- **Conditional Branches:**
  - `if (fAgent == NULL)`: Provisions default 10 agents; `else`: reads file and pads up to 10.
  - `if (sscanf(...) >= 4)`: Validates agent file record structure.
  - `if (fCounters != NULL)` vs `else`: Reads or defaults counters.
  - `if (nextComplaintNum < 101)`, `if (nextCustomerNum < 1001)`: Defensive counter clamping.
  - `if (fCust != NULL)`: Loads customer records.
  - `if (fComp != NULL)`: Loads complaint records.
  - `if (fAudit != NULL)`: Loads audit trail records.
  - `if (target != NULL)`: Links audit record to complaint.
- **Loop Conditions & Termination:**
  - Reads agent lines up to `MAX_AGENTS`.
  - Loops reading customers, complaints, and audit records until EOF.
- **Error Handling & Defensive Checks:** Handles missing files, partial files, corrupted counter values, unlinked audit logs, and malloc failures during load.
- **Side Effects:** Creates directories, reads files, allocates heap memory, modifies all global state variables.
- **Relevant Test Scenarios:**
  - Cold start: empty `data/` directory -> provisions 10 default agents, counters 101 and 1001.
  - Existing `data/agents.txt` loaded correctly.
  - Partial agent file (< 10 agents) padded with defaults.
  - Existing valid `data/counters.txt`.
  - Corrupt or invalid `data/counters.txt` -> defaults safely.
  - Counters below minimum limits -> clamped.
  - Populated customers file parsed into linked list.
  - Populated complaints file parsed into linked list.
  - Audit log entries loaded and linked to corresponding complaints.
  - Audit log record with unknown complaint ID ignored safely.

---

### Function 9: `saveAllData`
- **Source File & Line:** `src/main.c:379-450`
- **Purpose:** Flushes all current in-memory data structures (counters, agents, customers, complaints, audit events) to persistent disk files in pipe-delimited format.
- **Parameters:** `void`.
- **Valid Input Ranges:** N/A.
- **Return Type & Expected Result:** `void`. Files written to disk.
- **Normal Execution Paths:** Opens each file (`counters.txt`, `agents.txt`, `customers.txt`, `complaints.txt`, `audit_log.txt`), writes formatted records, closes files.
- **Conditional Branches:**
  - Checks `if (f != NULL)` for each file stream.
  - Checks for empty timestamp/note strings and substitutes defaults (`"N/A"`, `"No notes yet"`).
- **Loop Conditions & Termination:**
  - `for (int i = 0; i < MAX_AGENTS; i++)`: Writes all 10 agents.
  - `while (curr != NULL)`: Customer and complaint linked list iterations.
  - Nested `while (aNode != NULL)`: Writes all audit nodes for all complaints.
- **Error Handling & Defensive Checks:** Checks file open success for each target file.
- **Side Effects:** Writes persistent disk files.
- **Relevant Test Scenarios:**
  - Save empty lists (0 customers, 0 complaints).
  - Save populated customers and complaints.
  - Save records with empty timestamps and notes (triggers fallback string paths).
  - Verify file persistence and verify contents match in-memory data.
  - File failure simulation (mock `fopen` returning NULL).

---

### Function 10: `freeAllMemory`
- **Source File & Line:** `src/main.c:456-478`
- **Purpose:** Traverses and releases all dynamically allocated memory across customer linked lists, complaint linked lists, and nested audit event linked lists. Resets head pointers to `NULL`.
- **Parameters:** `void`.
- **Valid Input Ranges:** N/A.
- **Return Type & Expected Result:** `void`. All heap memory freed, `customerHead = NULL`, `complaintHead = NULL`.
- **Normal Execution Paths:** Traverses customer nodes freeing each; traverses complaint nodes, frees their audit node chains, then frees complaint node. Sets pointers to NULL.
- **Loop Conditions & Termination:**
  - Customer loop: `while (cCurr != NULL)`.
  - Complaint loop: `while (cmpCurr != NULL)`.
  - Audit loop: `while (aCurr != NULL)`.
- **Error Handling & Defensive Checks:** Safe to call when lists are already empty (handles NULL heads gracefully).
- **Side Effects:** Releases heap memory, sets global pointers to NULL.
- **Relevant Test Scenarios:**
  - Call on empty lists (both NULL) -> no crash.
  - Call with customers only.
  - Call with complaints without audit nodes.
  - Call with complaints containing multiple audit nodes.
  - Verify head pointers are NULL after execution.

---

### Function 11: `customerMenu`
- **Source File & Line:** `src/main.c:484-502`
- **Purpose:** Renders the pre-login Customer Portal menu allowing registration, login, or return to the main menu.
- **Parameters:** `void`.
- **Valid Input Ranges:** Interactive menu choices 1 to 3.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Loops presenting 3 options. Choice 1 invokes `customerRegister()`, Choice 2 invokes `customerLogin()`, Choice 3 breaks from loop.
- **Conditional Branches:**
  - `if (choice == 1)`: Registration path.
  - `else if (choice == 2)`: Login path.
  - `else`: Return to main menu break path.
- **Loop Conditions & Termination:**
  - `while (1)`: Loops until choice 3 is selected.
- **Error Handling & Defensive Checks:** Menu input validated via `readInt(..., 1, 3)`.
- **Side Effects:** Consumes stdin, prints to stdout.
- **Relevant Test Scenarios:**
  - Immediate exit (choice 3).
  - Navigate to registration (choice 1) then exit.
  - Navigate to login (choice 2) then exit.

---

### Function 12: `customerRegister`
- **Source File & Line:** `src/main.c:508-568`
- **Purpose:** Interactively registers a new customer account, validates mandatory fields, verifies username uniqueness, allocates a `CustomerNode`, appends to the customer list, assigns an auto-incremented `CUSTxxxx` ID, and persists data.
- **Parameters:** `void`.
- **Valid Input Ranges:** Non-empty name, unique username, non-empty password, non-empty contact.
- **Return Type & Expected Result:** `void`. New customer added to global state and saved.
- **Normal Execution Paths:** Prompts for full name, username, password, contact. Checks uniqueness via `findCustomerByUsername()`. Allocates node, sets sequential `CUST%04d` ID, appends to tail of `customerHead`, calls `saveAllData()`.
- **Conditional Branches:**
  - Blank full name -> aborts.
  - Blank username -> aborts.
  - Duplicate username -> aborts with error message.
  - Blank password -> aborts.
  - Blank contact -> aborts.
  - Malloc failure -> prints error, returns.
  - `if (customerHead == NULL)` vs `else`: Appends to head or tail.
- **Loop Conditions & Termination:**
  - Tail traversal: `while (curr->next != NULL)`.
- **Error Handling & Defensive Checks:** Validates all fields against empty strings; checks for username collision; checks malloc success.
- **Side Effects:** Allocates memory, increments `nextCustomerNum`, writes to disk via `saveAllData()`.
- **Relevant Test Scenarios:**
  - Successful registration of first customer.
  - Successful registration of subsequent customer (appended to tail).
  - Abort on blank full name.
  - Abort on blank username.
  - Abort on duplicate username.
  - Abort on blank password.
  - Abort on blank contact.
  - Heap allocation failure injection.

---

### Function 13: `customerLogin`
- **Source File & Line:** `src/main.c:573-588`
- **Purpose:** Prompts for customer credentials, verifies username and password, and launches the customer dashboard upon successful authentication.
- **Parameters:** `void`.
- **Valid Input Ranges:** Interactive strings for username and password.
- **Return Type & Expected Result:** `void`. Calls `customerDashboard()` on success, or prints failure message.
- **Normal Execution Paths:** Prompts for username and password via `readString()`. Looks up user via `findCustomerByUsername()`. If found and password matches, calls `customerDashboard()`.
- **Conditional Branches:**
  - `if (user != NULL && strcmp(user->data.password, password) == 0)`: Success branch.
  - `else`: Authentication failure branch.
- **Loop Conditions & Termination:** None.
- **Error Handling & Defensive Checks:** Handles non-existent usernames and incorrect passwords safely.
- **Side Effects:** Consumes stdin, writes stdout.
- **Relevant Test Scenarios:**
  - Successful login with valid credentials -> launches dashboard.
  - Non-existent username -> authentication failure.
  - Valid username with incorrect password -> authentication failure.

---

### Function 14: `customerDashboard`
- **Source File & Line:** `src/main.c:593-618`
- **Purpose:** Presents the authenticated customer dashboard with 5 options: Register complaint, View my complaints, Track complaint by ID, View complaint history, Logout.
- **Parameters:**
  - `const char *customerId`: Authenticated customer ID (e.g. `"CUST1001"`).
  - `const char *customerName`: Authenticated customer's full name.
- **Valid Input Ranges:** Non-null strings, choices 1 to 5.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Loops displaying menu options. Dispatches to corresponding handler based on user choice. Choice 5 exits loop.
- **Conditional Branches:**
  - `choice == 1`: calls `customerRegisterComplaint(customerId)`.
  - `choice == 2`: calls `customerViewComplaints(customerId)`.
  - `choice == 3`: calls `customerTrackComplaint(customerId)`.
  - `choice == 4`: calls `customerViewHistory(customerId)`.
  - `else` (choice 5): logs out and breaks.
- **Loop Conditions & Termination:**
  - `while (1)`: Loops until choice 5 (Logout).
- **Error Handling & Defensive Checks:** Input parsed with `readInt(..., 1, 5)`.
- **Side Effects:** Consumes stdin, writes stdout.
- **Relevant Test Scenarios:**
  - Immediate logout (choice 5).
  - Dispatch choice 1 -> register complaint.
  - Dispatch choice 2 -> view complaints.
  - Dispatch choice 3 -> track complaint.
  - Dispatch choice 4 -> view history.

---

### Function 15: `customerRegisterComplaint`
- **Source File & Line:** `src/main.c:624-725`
- **Purpose:** Registers a genuine customer complaint with a guaranteed sequential `CMPxxx` ID (starting strictly at `CMP101`), category, priority, description, auto-assigns an active agent, logs audit events, and saves persistent state.
- **Parameters:**
  - `const char *customerId`: ID of customer filing the complaint.
- **Valid Input Ranges:** Category 1-5, Priority 1-4, non-empty description.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Prompts category, priority, description. Finds next available unique `CMP%d` ID. Allocates `ComplaintNode`, sets timestamps, calls `autoAssignAgent()`. Appends to `complaintHead`, logs `"REGISTERED"` and `"ASSIGNED"` audit events, increments `nextComplaintNum`, saves data.
- **Conditional Branches:**
  - Blank description -> aborts.
  - Unique ID collision detection loop: `while (1) { if (findComplaintById == NULL) break; nextComplaintNum++; }`
  - Malloc failure -> prints error, returns.
  - `if (agentIdx >= 0)`: Agent assigned branch; `else`: Pending/unassigned branch.
  - `if (complaintHead == NULL)`: First complaint branch; `else`: Append to tail.
- **Loop Conditions & Termination:**
  - ID collision check: `while (1)` terminates when unused ID found.
  - Tail traversal: `while (curr->next != NULL)`.
- **Error Handling & Defensive Checks:** Empty description check, malloc check, fallback when no active agents available (`"PENDING"`).
- **Side Effects:** Allocates memory, appends to linked list, increments counter, writes disk files.
- **Relevant Test Scenarios:**
  - Successful complaint registration with active agents available (assigned).
  - Successful complaint registration with NO active agents (status PENDING, unassigned).
  - Abort on blank description.
  - ID collision avoidance loop (skips already existing CMP ID).
  - Append to empty complaintHead vs append to existing list.
  - Heap allocation failure injection.

---

### Function 16: `customerViewComplaints`
- **Source File & Line:** `src/main.c:731-759`
- **Purpose:** Displays a tabular summary of all complaints belonging exclusively to the authenticated customer, preserving data isolation.
- **Parameters:**
  - `const char *customerId`: Filter customer ID.
- **Valid Input Ranges:** Non-null string.
- **Return Type & Expected Result:** `void`. Prints table to `stdout`.
- **Normal Execution Paths:** Prints headers, traverses `complaintHead`, prints matching complaints, prints count summary.
- **Conditional Branches:**
  - `if (strcmp(curr->data.customerId, customerId) == 0)`: Ownership check.
  - `if (count == 0)`: "No complaints found" message; `else`: Total complaints count.
- **Loop Conditions & Termination:**
  - `while (curr != NULL)`: Traverses full complaint linked list.
- **Error Handling & Defensive Checks:** Handles empty complaint list and non-matching customers safely.
- **Side Effects:** Writes to stdout.
- **Relevant Test Scenarios:**
  - Customer has 0 complaints -> prints "No complaints found".
  - Customer has 1 complaint -> prints table with 1 row.
  - Customer has multiple complaints -> prints table with all matching rows.
  - System has complaints from other customers -> verifies data isolation (other customer complaints omitted).

---

### Function 17: `customerTrackComplaint`
- **Source File & Line:** `src/main.c:765-817`
- **Purpose:** Prompts for a complaint ID and displays its complete status card, progress timeline, and lifecycle stage progression, enforcing authorization checks.
- **Parameters:**
  - `const char *customerId`: Authenticated customer ID.
- **Valid Input Ranges:** Non-empty complaint ID.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Reads ID, locates node via `findComplaintById()`, verifies customer ownership, prints details, timestamps, and stage indicator.
- **Conditional Branches:**
  - `if (node == NULL)`: ID not found error.
  - `if (strcmp(node->data.customerId, customerId) != 0)`: Security violation error.
  - Status progression checks:
    - `strcmp(status, "PENDING") == 0`: Stage 1/5.
    - `strcmp(status, "ASSIGNED") == 0`: Stage 2/5.
    - `strcmp(status, "IN_PROGRESS") == 0`: Stage 3/5.
    - `strcmp(status, "ESCALATED") == 0`: Stage 3.5/5.
    - `strcmp(status, "RESOLVED") == 0`: Stage 4/5.
    - `strcmp(status, "CLOSED") == 0`: Stage 5/5.
    - `else`: Custom/unknown status state display.
- **Loop Conditions & Termination:** None.
- **Error Handling & Defensive Checks:** Handles non-existent ID and cross-customer access attempt.
- **Side Effects:** Consumes stdin, writes stdout.
- **Relevant Test Scenarios:**
  - Complaint ID not found.
  - Security violation: attempting to view another customer's complaint.
  - Successfully tracks complaint in "PENDING" status.
  - Successfully tracks complaint in "ASSIGNED" status.
  - Successfully tracks complaint in "IN_PROGRESS" status.
  - Successfully tracks complaint in "ESCALATED" status.
  - Successfully tracks complaint in "RESOLVED" status.
  - Successfully tracks complaint in "CLOSED" status.
  - Successfully tracks complaint with unrecognized status string.

---

### Function 18: `customerViewHistory`
- **Source File & Line:** `src/main.c:823-856`
- **Purpose:** Displays the full chronological audit trail of all actions performed on a specific customer complaint, enforcing data privacy.
- **Parameters:**
  - `const char *customerId`: Authenticated customer ID.
- **Valid Input Ranges:** Valid complaint ID belonging to this customer.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Reads complaint ID, validates existence and ownership, traverses `node->auditHead`, prints audit log records.
- **Conditional Branches:**
  - `if (node == NULL)`: ID not found error.
  - `if (strcmp(node->data.customerId, customerId) != 0)`: Authorization failure.
  - `if (count == 0)`: Empty audit history notice.
- **Loop Conditions & Termination:**
  - `while (an != NULL)`: Traverses all audit nodes in `node->auditHead`.
- **Error Handling & Defensive Checks:** Handles missing ID, security breach, and empty audit chains.
- **Side Effects:** Consumes stdin, writes stdout.
- **Relevant Test Scenarios:**
  - Complaint ID not found.
  - Security violation: accessing another customer's audit trail.
  - Successful view with empty audit history (0 entries).
  - Successful view with multiple audit trail entries.

---

### Function 19: `agentMenu`
- **Source File & Line:** `src/main.c:861-899`
- **Purpose:** Pre-login Agent Portal menu allowing agent login or return to main menu.
- **Parameters:** `void`.
- **Valid Input Ranges:** Menu choice 1 or 2; username and password strings.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Reads choice. Choice 1 prompts for agent credentials, verifies against `agents[]` array, checks `isActive`, and launches `agentDashboard()`. Choice 2 exits loop.
- **Conditional Branches:**
  - `choice == 1`: Login workflow; `else`: Return.
  - `if (foundIdx >= 0)`: Matching credentials found.
  - `if (!agents[foundIdx].isActive)`: Inactive account rejection.
  - `else`: Successful login -> `agentDashboard()`.
  - `else`: Authentication failure message.
- **Loop Conditions & Termination:**
  - `while (1)`: Loops until choice 2 is selected.
  - Credential scan: `for (int i = 0; i < MAX_AGENTS; i++)`.
- **Error Handling & Defensive Checks:** Validates credentials; enforces active account requirement.
- **Side Effects:** Consumes stdin, writes stdout.
- **Relevant Test Scenarios:**
  - Immediate exit (choice 2).
  - Invalid credentials -> authentication failed message.
  - Valid credentials for an INACTIVE agent -> access denied message.
  - Valid credentials for an ACTIVE agent -> launches `agentDashboard()`.

---

### Function 20: `agentDashboard`
- **Source File & Line:** `src/main.c:905-955`
- **Purpose:** Logged-in support agent dashboard displaying live workload, resolved metrics, and operational options (View assigned, Update complaint, View audit history, Logout).
- **Parameters:**
  - `int agentIdx`: Index of logged-in agent in `agents[]`.
- **Valid Input Ranges:** `0 <= agentIdx < MAX_AGENTS`.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Calculates active workload, displays header, prompts choice 1-4. Dispatches to assigned tools. Choice 4 breaks loop.
- **Conditional Branches:**
  - Active workload counting: `if (curr->data.assignedAgentId == agentId && status != "RESOLVED" && status != "CLOSED") activeCount++;`
  - `choice == 1`: calls `agentViewAssigned()`.
  - `choice == 2`: calls `agentUpdateComplaint()`.
  - `choice == 3`: audit history lookup (handles found vs not found).
  - `else` (choice 4): logout.
- **Loop Conditions & Termination:**
  - `while (1)`: Loops until logout (choice 4).
  - Workload calculation: `while (curr != NULL)`.
  - Audit history print: `while (an != NULL)`.
- **Error Handling & Defensive Checks:** Input range checked via `readInt(..., 1, 4)`. Safe check for non-existent complaint ID during history lookup.
- **Side Effects:** Consumes stdin, writes stdout.
- **Relevant Test Scenarios:**
  - Immediate logout (choice 4).
  - Choice 1: view assigned complaints.
  - Choice 2: update complaint.
  - Choice 3: audit history lookup for non-existent complaint.
  - Choice 3: audit history lookup for existing complaint.

---

### Function 21: `agentViewAssigned`
- **Source File & Line:** `src/main.c:961-990`
- **Purpose:** Renders a table of all complaints currently assigned to the given agent ID.
- **Parameters:**
  - `const char *agentId`: Agent ID to query (e.g. `"AGT101"`).
- **Valid Input Ranges:** Non-null string.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Prints headers, iterates `complaintHead`, prints complaints matching `assignedAgentId`, prints count.
- **Conditional Branches:**
  - `if (strcmp(curr->data.assignedAgentId, agentId) == 0)`: Assignment filter.
  - `if (count == 0)`: "No complaints assigned" message; `else`: Total assigned count.
- **Loop Conditions & Termination:**
  - `while (curr != NULL)`: Traverses complaint linked list.
- **Error Handling & Defensive Checks:** Safe on empty list and non-matching agents.
- **Side Effects:** Writes to stdout.
- **Relevant Test Scenarios:**
  - Agent has 0 complaints assigned -> prints notice.
  - Agent has 1 complaint assigned -> prints table row.
  - Agent has multiple complaints assigned.
  - Other agents' complaints are excluded.

---

### Function 22: `agentUpdateComplaint`
- **Source File & Line:** `src/main.c:995-1058`
- **Purpose:** Allows a support agent to progress a ticket assigned to them to `IN_PROGRESS`, `RESOLVED`, or `ESCALATED`, appending progress notes and timestamps.
- **Parameters:**
  - `const char *agentId`: Logged-in agent ID.
- **Valid Input Ranges:** Complaint ID assigned to this agent; action choice 1 to 4.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Reads complaint ID, validates existence and assignment. Prompts action: 1: IN_PROGRESS, 2: RESOLVED, 3: ESCALATED, 4: Cancel. Reads note, updates timestamp, status, last note, resolvedCount (if resolved), appends audit entry, and saves data.
- **Conditional Branches:**
  - `if (node == NULL)`: Complaint not found error.
  - `if (strcmp(node->data.assignedAgentId, agentId) != 0)`: Not assigned to agent error.
  - `if (choice == 4)`: Action cancelled.
  - `if (note[0] == '\0')`: Default note assignment.
  - `if (choice == 1)`: IN_PROGRESS transition.
  - `else if (choice == 2)`: RESOLVED transition (increments agent's `resolvedCount`).
  - `else if (choice == 3)`: ESCALATED transition.
- **Loop Conditions & Termination:**
  - Agent resolved counter lookup: `for (int i = 0; i < MAX_AGENTS; i++)`.
- **Error Handling & Defensive Checks:** Validates ticket assignment; handles non-existent ID; fallback for empty note.
- **Side Effects:** Modifies complaint data and timestamps, increments `resolvedCount`, creates audit node, writes to disk.
- **Relevant Test Scenarios:**
  - Complaint ID not found.
  - Complaint not assigned to logged-in agent.
  - Action cancelled (choice 4).
  - Update to `IN_PROGRESS` with custom note.
  - Update to `IN_PROGRESS` with empty note (triggers default note).
  - Update to `RESOLVED` (verifies timestamp set, `resolvedCount` incremented).
  - Update to `ESCALATED` (verifies timestamp set and audit logged).

---

### Function 23: `managerMenu`
- **Source File & Line:** `src/main.c:1064-1090`
- **Purpose:** Pre-login Manager Portal menu for system administrator authentication.
- **Parameters:** `void`.
- **Valid Input Ranges:** Menu choice 1 or 2; username and password strings.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Reads choice. Choice 1 prompts for manager credentials, compares with `managerAccount`, launches `managerDashboard()` on match. Choice 2 returns.
- **Conditional Branches:**
  - `choice == 1`: Authentication workflow; `else`: Return.
  - `if (credentials match)`: Dashboard launch; `else`: Failure message.
- **Loop Conditions & Termination:**
  - `while (1)`: Loops until choice 2 is selected.
- **Error Handling & Defensive Checks:** Validates credentials securely.
- **Side Effects:** Consumes stdin, writes stdout.
- **Relevant Test Scenarios:**
  - Immediate exit (choice 2).
  - Invalid credentials -> authentication failed.
  - Valid manager credentials (`manager` / `manager123`) -> launches dashboard.

---

### Function 24: `managerDashboard`
- **Source File & Line:** `src/main.c:1096-1144`
- **Purpose:** Central administrative control panel offering 6 options: View all complaints, Assign/reassign complaints, Update complaint status, Agent management, View complete audit log, Logout.
- **Parameters:** `void`.
- **Valid Input Ranges:** Interactive menu choices 1 to 6.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Loops displaying options. Dispatches to selected managerial tool. Choice 6 logs out.
- **Conditional Branches:**
  - `choice == 1`: calls `managerViewAllComplaints()`.
  - `choice == 2`: calls `managerAssignComplaint()`.
  - `choice == 3`: calls `managerUpdateComplaint()`.
  - `choice == 4`: calls `managerAgentManagement()`.
  - `choice == 5`: views complete system audit history (handles 0 vs >0 events).
  - `else` (choice 6): logout.
- **Loop Conditions & Termination:**
  - `while (1)`: Loops until logout (choice 6).
  - Full audit traversal: `while (cNode != NULL) { while (aNode != NULL) { ... } }`.
- **Error Handling & Defensive Checks:** Range checked with `readInt(..., 1, 6)`.
- **Side Effects:** Consumes stdin, writes stdout.
- **Relevant Test Scenarios:**
  - Immediate logout (choice 6).
  - Choice 1: view all complaints.
  - Choice 2: assign complaint.
  - Choice 3: update complaint.
  - Choice 4: agent management.
  - Choice 5: view complete audit history when 0 events exist.
  - Choice 5: view complete audit history when multiple events exist.

---

### Function 25: `managerViewAllComplaints`
- **Source File & Line:** `src/main.c:1150-1194`
- **Purpose:** Renders an executive KPI metrics summary (Total, Pending, Assigned, In Progress, Resolved, Closed, Escalated) followed by a complete tabular roster of all complaints in the system.
- **Parameters:** `void`.
- **Valid Input Ranges:** N/A.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** First loop traverses `complaintHead` tallying metric counters by status. Prints dashboard box. Second loop prints details for each complaint.
- **Conditional Branches:**
  - Metric counting: `if (status == "PENDING") ... else if (status == "ASSIGNED") ... else if (status == "IN_PROGRESS") ... else if (status == "RESOLVED") ... else if (status == "CLOSED") ... else if (status == "ESCALATED")`.
  - `if (total == 0)`: Prints "Zero complaints exist in the system."
- **Loop Conditions & Termination:**
  - Metrics traversal: `while (curr != NULL)`.
  - Display traversal: `while (curr != NULL)`.
- **Error Handling & Defensive Checks:** Handles empty complaint database safely.
- **Side Effects:** Writes to stdout.
- **Relevant Test Scenarios:**
  - 0 complaints in system -> verifies KPIs all 0 and empty notice printed.
  - Populated complaints covering each lifecycle status -> verifies correct KPI totals and table rows.

---

### Function 26: `managerAssignComplaint`
- **Source File & Line:** `src/main.c:1200-1271`
- **Purpose:** Allows the manager to manually assign or reassign any complaint to an active support agent, preventing assignment to inactive agents.
- **Parameters:** `void`.
- **Valid Input Ranges:** Valid complaint ID, valid agent ID (`AGT101`-`AGT110`).
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Reads complaint ID, validates existence. Displays agent roster with live workloads. Reads target agent ID, verifies existence and active status. Updates `assignedAgentId`, timestamps, status (if pending -> assigned), note, audit log, and persists data.
- **Conditional Branches:**
  - `if (node == NULL)`: Complaint not found error.
  - `if (targetIdx == -1)`: Agent ID does not exist error.
  - `if (!agents[targetIdx].isActive)`: Inactive agent warning and abort.
  - `if (strcmp(node->data.status, "PENDING") == 0)`: Automatically promotes status to `"ASSIGNED"`.
- **Loop Conditions & Termination:**
  - Workload calculation: `for (int i = 0; i < MAX_AGENTS; i++)` with inner `while (c != NULL)`.
  - Target agent lookup: `for (int i = 0; i < MAX_AGENTS; i++)`.
- **Error Handling & Defensive Checks:** Handles non-existent complaint, non-existent agent ID, and prevents assignment to inactive agents.
- **Side Effects:** Modifies complaint assignment, status, timestamps, audit trail; persists data to disk.
- **Relevant Test Scenarios:**
  - Complaint ID not found.
  - Target agent ID does not exist.
  - Target agent is INACTIVE -> aborts with warning.
  - Successful assignment of a PENDING complaint -> status promoted to ASSIGNED.
  - Successful reassignment of an already ASSIGNED/IN_PROGRESS complaint.

---

### Function 27: `managerUpdateComplaint`
- **Source File & Line:** `src/main.c:1277-1334`
- **Purpose:** Administrative complaint status transition allowing the manager to set status to `IN_PROGRESS`, `RESOLVED`, `CLOSED`, or `ESCALATED` with audit notes.
- **Parameters:** `void`.
- **Valid Input Ranges:** Valid complaint ID; action choice 1 to 5.
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Reads complaint ID, validates existence. Prompts action choice (1: IN_PROGRESS, 2: RESOLVED, 3: CLOSED, 4: ESCALATED, 5: Cancel). Reads administrative note, updates status, corresponding timestamp, last note, audit trail, and persists data.
- **Conditional Branches:**
  - `if (node == NULL)`: Complaint not found error.
  - `if (choice == 5)`: Action cancelled.
  - `if (note[0] == '\0')`: Default note assignment.
  - `choice == 1`: IN_PROGRESS.
  - `choice == 2`: RESOLVED (sets resolved timestamp).
  - `choice == 3`: CLOSED (sets closed timestamp).
  - `choice == 4`: ESCALATED (sets escalated timestamp).
- **Loop Conditions & Termination:** None.
- **Error Handling & Defensive Checks:** Handles missing complaint ID; fallback for empty note; cancellation option.
- **Side Effects:** Updates complaint status, timestamps, audit history; persists to disk.
- **Relevant Test Scenarios:**
  - Complaint ID not found.
  - Action cancelled (choice 5).
  - Transition to `IN_PROGRESS` with custom note.
  - Transition to `RESOLVED` with empty note (triggers default note, sets resolved timestamp).
  - Transition to `CLOSED` (sets closed timestamp).
  - Transition to `ESCALATED` (sets escalated timestamp).

---

### Function 28: `managerAgentManagement`
- **Source File & Line:** `src/main.c:1340-1391`
- **Purpose:** Displays support agent performance metrics (workload, resolved count) and allows toggling an agent's availability (`ACTIVE` / `INACTIVE`).
- **Parameters:** `void`.
- **Valid Input Ranges:** Choice 1 or 2; Agent ID string (`AGT101`-`AGT110`).
- **Return Type & Expected Result:** `void`.
- **Normal Execution Paths:** Loops displaying agent table with live active workloads and resolved counts. Choice 1 prompts for Agent ID, searches `agents[]`, toggles `isActive`, saves data. Choice 2 returns to manager menu.
- **Conditional Branches:**
  - Workload calculation filter for each agent.
  - `if (choice == 1)`: Toggle workflow; `else`: Return.
  - `if (found != -1)`: Agent found -> toggles `isActive = !isActive`; `else`: Agent ID not found error.
- **Loop Conditions & Termination:**
  - `while (1)`: Loops until choice 2.
  - Table workload calculation: `for (int i = 0; i < MAX_AGENTS; i++)` with inner `while (c != NULL)`.
  - Agent lookup: `for (int i = 0; i < MAX_AGENTS; i++)`.
- **Error Handling & Defensive Checks:** Handles non-existent agent ID gracefully.
- **Side Effects:** Toggles `isActive` flag, saves data to disk.
- **Relevant Test Scenarios:**
  - Immediate return (choice 2).
  - Toggle with non-existent agent ID -> error message.
  - Toggle active agent to inactive -> status changes to INACTIVE.
  - Toggle inactive agent back to active -> status changes to ACTIVE.

---

### Function 29: `main`
- **Source File & Line:** `src/main.c:1397-1427`
- **Purpose:** Application entry point executing system initialization (`initSystem()`), displaying the mandatory 4-option main menu (Customer, Agent, Manager, Exit), and performing clean data persistence and memory deallocation upon graceful exit.
- **Parameters:** `void`.
- **Valid Input Ranges:** Interactive menu choice 1 to 4.
- **Return Type & Expected Result:** `int`. Returns 0 on successful termination.
- **Normal Execution Paths:** Calls `initSystem()`. Enters main event loop displaying options. Dispatches to `customerMenu()` (1), `agentMenu()` (2), `managerMenu()` (3). On Choice 4, calls `saveAllData()`, `freeAllMemory()`, prints exit message, and terminates returning 0.
- **Conditional Branches:**
  - `if (choice == 1)`: Customer portal.
  - `else if (choice == 2)`: Agent portal.
  - `else if (choice == 3)`: Manager portal.
  - `else if (choice == 4)`: Graceful shutdown and exit.
- **Loop Conditions & Termination:**
  - `while (1)`: Main application event loop, terminated by choice 4.
- **Error Handling & Defensive Checks:** Menu input validated via `readInt(..., 1, 4)`.
- **Side Effects:** Initializes global state, saves persistent state, frees all allocated heap memory.
- **Relevant Test Scenarios:**
  - Immediate exit (choice 4) -> calls saveAllData, freeAllMemory, returns 0.
  - Navigate to customer menu then return and exit.
  - Navigate to agent menu then return and exit.
  - Navigate to manager menu then return and exit.

---
