#include "test_helpers.h"

class MainFunctionTest : public ::testing::Test {
protected:
    ScopedSandbox sandbox;

    void SetUp() override {}
    void TearDown() override {
        freeAllMemory();
    }
};

/* ========================================================================= */
/* FUNCTION 29: main (exercised as app_main) Tests                           */
/* ========================================================================= */

TEST_F(MainFunctionTest, Main_ImmediateExit) {
    // Choice 4: Exit immediately
    StdioCapture capture("4\n");
    int result = app_main();

    EXPECT_EQ(result, 0);
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("COMPLAINT HANDLING SYSTEM"), std::string::npos);
    EXPECT_NE(out.find("Saving system state and releasing resources"), std::string::npos);
    EXPECT_NE(out.find("Thank you for using the Complaint Handling System. Goodbye!"), std::string::npos);
}

TEST_F(MainFunctionTest, Main_FullMenuNavigationCycle) {
    // 1: Customer Menu -> 3: Return to Main Menu
    // 2: Agent Menu -> 2: Return to Main Menu
    // 3: Manager Menu -> 2: Return to Main Menu
    // 4: Exit System
    StdioCapture capture("1\n3\n2\n2\n3\n2\n4\n");
    int result = app_main();

    EXPECT_EQ(result, 0);
    std::string out = capture.getOutput();
    EXPECT_NE(out.find("CUSTOMER PORTAL"), std::string::npos);
    EXPECT_NE(out.find("AGENT PORTAL"), std::string::npos);
    EXPECT_NE(out.find("MANAGER PORTAL"), std::string::npos);
    EXPECT_NE(out.find("Saving system state and releasing resources"), std::string::npos);
}

/* ========================================================================= */
/* Google Test Runner Entry Point                                            */
/* ========================================================================= */

int main(int argc, char **argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
