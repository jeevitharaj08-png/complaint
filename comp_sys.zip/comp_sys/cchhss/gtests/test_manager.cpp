#include "test_helpers.h"

class ManagerTest : public ::testing::Test {
protected:
    ScopedSandbox sandbox;

    void SetUp() override {
        initSystem();
    }

    void TearDown() override {
        freeAllMemory();
    }
};

/* ========================================================================= */
/* FUNCTION 24: managerDashboard Tests                                       */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerDashboard_LogoutDirectly) {
    StdioCapture capture("6\n"); // Choice 6: Logout
    managerDashboard();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("MANAGER DASHBOARD"), std::string::npos);
    EXPECT_NE(out.find("Logging out of manager session"), std::string::npos);
}

TEST_F(ManagerTest, ManagerDashboard_SubmenuDispatchAndAuditLogs) {
    // 1. View audit history when count == 0 (no audit events logged yet)
    {
        StdioCapture capture("5\n6\n");
        managerDashboard();
        EXPECT_NE(capture.getOutput().find("No audit events logged in system yet"), std::string::npos);
    }

    // 2. Populate complaints and audit events
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
    sandbox.writeFile("data/audit_log.txt",
        "CMP101|2026-01-01 10:00:00|REGISTERED|CUST1001|Initial complaint\n");
    initSystem();

    // 1: view all complaints, 2: assign (cancel via CMP999), 3: update (cancel via CMP999),
    // 4: agent management (exit via 2), 5: view complete audit history, 6: logout
    StdioCapture capture("1\n2\nCMP999\n3\nCMP999\n4\n2\n5\n6\n");
    managerDashboard();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("SYSTEM METRICS & DASHBOARD"), std::string::npos);
    EXPECT_NE(out.find("Enter Complaint ID to assign"), std::string::npos);
    EXPECT_NE(out.find("Enter Complaint ID to update"), std::string::npos);
    EXPECT_NE(out.find("SUPPORT AGENT MANAGEMENT"), std::string::npos);
    EXPECT_NE(out.find("Complete System Audit History"), std::string::npos);
    EXPECT_NE(out.find("Initial complaint"), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 25: managerViewAllComplaints Tests                               */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerViewAllComplaints_ZeroComplaints) {
    StdioCapture capture;
    managerViewAllComplaints();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Total Complaints:  0"), std::string::npos);
    EXPECT_NE(out.find("Zero complaints exist in the system"), std::string::npos);
}

TEST_F(ManagerTest, ManagerViewAllComplaints_AllStatusesCovered) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Category|Low|PENDING|UNASSIGNED|2026-01-01 10:00:00|N/A|2026-01-01 10:00:00|N/A|N/A|N/A|Note|1\n"
        "CMP102|CUST1001|Category|Low|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|2\n"
        "CMP103|CUST1001|Category|Low|IN_PROGRESS|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|3\n"
        "CMP104|CUST1001|Category|Low|RESOLVED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|N/A|N/A|Note|4\n"
        "CMP105|CUST1001|Category|Low|CLOSED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|2026-01-01 12:00:00|N/A|Note|5\n"
        "CMP106|CUST1001|Category|Low|ESCALATED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|2026-01-01 10:30:00|Note|6\n"
        "CMP107|CUST1001|Category|Low|CUSTOM_STATUS|AGT101|2026-01-01 10:00:00|N/A|2026-01-01 10:00:00|N/A|N/A|N/A|Note|7\n");
    initSystem();

    StdioCapture capture;
    managerViewAllComplaints();

    std::string out = capture.getOutput();
    EXPECT_NE(out.find("Total Complaints:  7"), std::string::npos);
    EXPECT_NE(out.find("Pending:     1"), std::string::npos);
    EXPECT_NE(out.find("Assigned:  1"), std::string::npos);
    EXPECT_NE(out.find("In Progress:       1"), std::string::npos);
    EXPECT_NE(out.find("Escalated:   1"), std::string::npos);
    EXPECT_NE(out.find("Resolved:  1"), std::string::npos);
    EXPECT_NE(out.find("Closed:            1"), std::string::npos);
}

/* ========================================================================= */
/* FUNCTION 26: managerAssignComplaint Tests                                 */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerAssignComplaint_NotFoundAndInactiveValidation) {
    // 1. Complaint not found
    {
        StdioCapture capture("CMP999\n");
        managerAssignComplaint();
        EXPECT_NE(capture.getOutput().find("Error: Complaint ID 'CMP999' not found"), std::string::npos);
    }
    // 2. Target agent does not exist
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|PENDING|UNASSIGNED|2026-01-01 10:00:00|N/A|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        initSystem();

        StdioCapture capture("CMP101\nAGT999\n");
        managerAssignComplaint();
        EXPECT_NE(capture.getOutput().find("Error: Agent ID 'AGT999' does not exist"), std::string::npos);
    }
    // 3. Target agent is inactive
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|PENDING|UNASSIGNED|2026-01-01 10:00:00|N/A|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        sandbox.writeFile("data/agents.txt",
            "AGT101|Alice Smith|agent1|agentpass1|1|0\n"
            "AGT102|Bob Johnson|agent2|agentpass2|0|0\n");
        initSystem();

        StdioCapture capture("CMP101\nAGT102\n");
        managerAssignComplaint();
        EXPECT_NE(capture.getOutput().find("Warning: Agent AGT102 is inactive. Reassignment aborted"), std::string::npos);
    }
}

TEST_F(ManagerTest, ManagerAssignComplaint_SuccessPendingAndReassignment) {
    freeAllMemory();
    sandbox.writeFile("data/complaints.txt",
        "CMP101|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|T1\n"
        "CMP102|CUST1001|Technical Support|High|RESOLVED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|N/A|N/A|Note|T2\n"
        "CMP103|CUST1001|Technical Support|High|CLOSED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|2026-01-01 12:00:00|N/A|Note|T3\n"
        "CMP104|CUST1001|Billing|Low|PENDING|UNASSIGNED|2026-01-01 10:00:00|N/A|2026-01-01 10:00:00|N/A|N/A|N/A|Note|T4\n");
    initSystem();

    // 1. Assign PENDING complaint (promotes status to ASSIGNED)
    {
        StdioCapture capture("CMP104\nAGT101\n");
        managerAssignComplaint();
        EXPECT_NE(capture.getOutput().find("[SUCCESS] Complaint CMP104 successfully assigned to AGT101"), std::string::npos);
    }
    // 2. Reassign already ASSIGNED complaint
    {
        StdioCapture capture("CMP101\nAGT102\n");
        managerAssignComplaint();
        EXPECT_NE(capture.getOutput().find("[SUCCESS] Complaint CMP101 successfully assigned to AGT102"), std::string::npos);
    }
}

/* ========================================================================= */
/* FUNCTION 27: managerUpdateComplaint Tests                                 */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerUpdateComplaint_NotFoundCancelAndStatusTransitions) {
    // 1. Complaint not found
    {
        StdioCapture capture("CMP999\n");
        managerUpdateComplaint();
        EXPECT_NE(capture.getOutput().find("Error: Complaint ID 'CMP999' not found"), std::string::npos);
    }
    // 2. Action cancelled (choice 5)
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|PENDING|UNASSIGNED|2026-01-01 10:00:00|N/A|2026-01-01 10:00:00|N/A|N/A|N/A|Note|Desc\n");
        initSystem();

        StdioCapture capture("CMP101\n5\n");
        managerUpdateComplaint();
        EXPECT_NE(capture.getOutput().find("Action cancelled"), std::string::npos);
    }
    // 3. Status 1: IN_PROGRESS (empty note)
    {
        StdioCapture c("CMP101\n1\n\n");
        managerUpdateComplaint();
        ComplaintNode *n = findComplaintById("CMP101");
        ASSERT_NE(n, nullptr);
        EXPECT_STREQ(n->data.status, "IN_PROGRESS");
        EXPECT_STREQ(n->data.lastNote, "Status updated by Manager");
    }
    // 4. Status 2: RESOLVED
    {
        StdioCapture c("CMP101\n2\nManager confirmed resolution\n");
        managerUpdateComplaint();
        ComplaintNode *n = findComplaintById("CMP101");
        ASSERT_NE(n, nullptr);
        EXPECT_STREQ(n->data.status, "RESOLVED");
        EXPECT_STRNE(n->data.timestamps.resolved, "N/A");
    }
    // 5. Status 3: CLOSED
    {
        StdioCapture c("CMP101\n3\nCase formally closed\n");
        managerUpdateComplaint();
        ComplaintNode *n = findComplaintById("CMP101");
        ASSERT_NE(n, nullptr);
        EXPECT_STREQ(n->data.status, "CLOSED");
        EXPECT_STRNE(n->data.timestamps.closed, "N/A");
    }
    // 6. Status 4: ESCALATED
    {
        StdioCapture c("CMP101\n4\nExecutive escalation\n");
        managerUpdateComplaint();
        ComplaintNode *n = findComplaintById("CMP101");
        ASSERT_NE(n, nullptr);
        EXPECT_STREQ(n->data.status, "ESCALATED");
        EXPECT_STRNE(n->data.timestamps.escalated, "N/A");
    }
}

/* ========================================================================= */
/* FUNCTION 28: managerAgentManagement Tests                                 */
/* ========================================================================= */

TEST_F(ManagerTest, ManagerAgentManagement_ReturnNotFoundAndToggle) {
    // 1. Direct return (choice 2)
    {
        StdioCapture capture("2\n");
        managerAgentManagement();
        EXPECT_NE(capture.getOutput().find("SUPPORT AGENT MANAGEMENT"), std::string::npos);
    }
    // 2. Toggle non-existent agent
    {
        StdioCapture capture("1\nAGT999\n2\n");
        managerAgentManagement();
        EXPECT_NE(capture.getOutput().find("Error: Agent ID 'AGT999' not found"), std::string::npos);
    }
    // 3. Toggle active to inactive and back to active with workload counting loop
    {
        freeAllMemory();
        sandbox.writeFile("data/complaints.txt",
            "CMP101|CUST1001|Technical Support|High|IN_PROGRESS|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|T1\n"
            "CMP102|CUST1001|Technical Support|High|ASSIGNED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|N/A|N/A|N/A|Note|T2\n"
            "CMP103|CUST1001|Technical Support|High|RESOLVED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|N/A|N/A|Note|T3\n"
            "CMP104|CUST1001|Technical Support|High|CLOSED|AGT101|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 10:00:00|2026-01-01 11:00:00|2026-01-01 12:00:00|N/A|Note|T4\n");
        initSystem();

        StdioCapture capture("1\nAGT101\n1\nAGT101\n2\n");
        managerAgentManagement();
        std::string out = capture.getOutput();
        EXPECT_NE(out.find("Agent AGT101 status toggled to INACTIVE"), std::string::npos);
        EXPECT_NE(out.find("Agent AGT101 status toggled to ACTIVE"), std::string::npos);
    }
}
