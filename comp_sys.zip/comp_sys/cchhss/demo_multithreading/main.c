/**
 * @file main.c
 * @brief Standalone POSIX Multithreading Demonstration (CCHHSS Presentation Demo)
 *
 * This program is an independent demonstration of POSIX thread (pthread) concurrency,
 * race conditions, mutual exclusion (mutex), and safe thread lifecycle management.
 *
 * It is completely decoupled from the production Complaint Handling System.
 *
 * Requirements demonstrated:
 * 1. Creates exactly four worker threads.
 * 2. Each worker increments a shared counter 100,000 times.
 * 3. Protects the shared counter with a pthread_mutex_t.
 * 4. Joins every successfully created thread.
 * 5. Robust error checking on thread creation, mutex initialization, lock/unlock, and join.
 * 6. Handles partial thread-creation failure safely (joins previously created threads before cleanup).
 * 7. Destroys the mutex only after all worker threads have terminated.
 * 8. Prints expected counter (400,000) and actual final counter.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <errno.h>

#define NUM_WORKERS 4
#define INCREMENTS_PER_THREAD 100000L
#define EXPECTED_FINAL_COUNT ((long)NUM_WORKERS * INCREMENTS_PER_THREAD)

/* Thread shared resource structure */
typedef struct {
    pthread_mutex_t lock;      /* Mutual exclusion lock */
    long shared_counter;       /* Shared resource guarded by mutex */
} SharedResource;

/* Worker context passed to each thread */
typedef struct {
    int worker_id;             /* Worker index: 0, 1, 2, 3 */
    long iterations;           /* Number of increments: 100,000 */
    SharedResource *resource;  /* Pointer to shared state */
} WorkerArg;

/**
 * @brief Thread routine executed concurrently by each worker.
 *
 * Each thread performs 100,000 atomic increments on the shared counter.
 * Critical section is strictly guarded by the pthread_mutex.
 */
static void* worker_routine(void *arg) {
    WorkerArg *warg = (WorkerArg *)arg;
    if (warg == NULL || warg->resource == NULL) {
        pthread_exit((void *)(intptr_t)-1);
    }

    SharedResource *res = warg->resource;

    for (long i = 0; i < warg->iterations; ++i) {
        int rc = pthread_mutex_lock(&res->lock);
        if (rc != 0) {
            fprintf(stderr, "[Worker %d] ERROR: pthread_mutex_lock failed (code: %d)\n",
                    warg->worker_id, rc);
            pthread_exit((void *)(intptr_t)rc);
        }

        /* --- CRITICAL SECTION BEGIN --- */
        res->shared_counter++;
        /* --- CRITICAL SECTION END --- */

        rc = pthread_mutex_unlock(&res->lock);
        if (rc != 0) {
            fprintf(stderr, "[Worker %d] ERROR: pthread_mutex_unlock failed (code: %d)\n",
                    warg->worker_id, rc);
            pthread_exit((void *)(intptr_t)rc);
        }
    }

    pthread_exit(NULL);
    return NULL;
}

int main(void) {
    printf("======================================================================\n");
    printf("          POSIX MULTITHREADING & SYNCHRONIZATION DEMO\n");
    printf("======================================================================\n");
    printf("[INFO] Number of worker threads : %d\n", NUM_WORKERS);
    printf("[INFO] Increments per thread    : %ld\n", INCREMENTS_PER_THREAD);
    printf("[INFO] Expected final counter   : %ld\n", EXPECTED_FINAL_COUNT);
    printf("----------------------------------------------------------------------\n");

    SharedResource resource;
    resource.shared_counter = 0;

    /* 1. Initialize POSIX mutex */
    int rc = pthread_mutex_init(&resource.lock, NULL);
    if (rc != 0) {
        fprintf(stderr, "[FATAL] Failed to initialize pthread mutex: %s (code %d)\n",
                strerror(rc), rc);
        return EXIT_FAILURE;
    }

    pthread_t threads[NUM_WORKERS];
    WorkerArg thread_args[NUM_WORKERS];
    int threads_created = 0;
    int creation_failed = 0;

    /* 2. Create worker threads with error handling and partial-failure recovery */
    for (int i = 0; i < NUM_WORKERS; ++i) {
        thread_args[i].worker_id = i + 1;
        thread_args[i].iterations = INCREMENTS_PER_THREAD;
        thread_args[i].resource = &resource;

        rc = pthread_create(&threads[i], NULL, worker_routine, &thread_args[i]);
        if (rc != 0) {
            fprintf(stderr, "[ERROR] pthread_create failed for worker %d: %s (code %d)\n",
                    i + 1, strerror(rc), rc);
            creation_failed = 1;
            break;
        }
        threads_created++;
        printf("[INFO] Worker thread %d created successfully (TID: %lu).\n",
               i + 1, (unsigned long)threads[i]);
    }

    /* 3. Join all threads that were successfully created */
    int join_errors = 0;
    for (int i = 0; i < threads_created; ++i) {
        void *thread_ret = NULL;
        rc = pthread_join(threads[i], &thread_ret);
        if (rc != 0) {
            fprintf(stderr, "[ERROR] pthread_join failed for worker %d: %s (code %d)\n",
                    i + 1, strerror(rc), rc);
            join_errors++;
        } else if (thread_ret != NULL) {
            fprintf(stderr, "[WARNING] Worker %d returned non-zero status: %ld\n",
                    i + 1, (long)(intptr_t)thread_ret);
        } else {
            printf("[INFO] Worker thread %d joined successfully.\n", i + 1);
        }
    }

    /* 4. Destroy mutex only after all workers have completed and joined */
    rc = pthread_mutex_destroy(&resource.lock);
    if (rc != 0) {
        fprintf(stderr, "[ERROR] pthread_mutex_destroy failed: %s (code %d)\n",
                strerror(rc), rc);
    }

    /* 5. Report results */
    printf("----------------------------------------------------------------------\n");
    printf(" Expected Counter : %ld\n", EXPECTED_FINAL_COUNT);
    printf(" Actual Counter   : %ld\n", resource.shared_counter);
    printf(" Threads Created  : %d of %d\n", threads_created, NUM_WORKERS);
    printf(" Join Errors      : %d\n", join_errors);
    printf("----------------------------------------------------------------------\n");

    if (creation_failed || join_errors > 0) {
        fprintf(stderr, "[FAILURE] Multithreading execution encountered errors.\n");
        return EXIT_FAILURE;
    }

    if (resource.shared_counter == EXPECTED_FINAL_COUNT) {
        printf(" [SUCCESS] Thread safety verified! Zero race conditions detected.\n");
        printf("======================================================================\n");
        return EXIT_SUCCESS;
    } else {
        fprintf(stderr, " [FAILURE] Data race detected! Counter mismatch: got %ld, expected %ld.\n",
                resource.shared_counter, EXPECTED_FINAL_COUNT);
        printf("======================================================================\n");
        return EXIT_FAILURE;
    }
}
